========================================================================
UNIVERSAL BILLING & POS - WINDOWS INSTALLER SETUP GUIDE
========================================================================
1. Double-click 'Install-Desktop-Shortcut.vbs' to create an icon on your desktop.
2. Launch 'UniversalBillingPOS-Setup.bat'.
3. On the Terminal login screen, punch your 6-digit PIN:
   - Store Owner: 123456
   - Store Manager: 654321
   - Store Cashier: 999999
========================================================================
