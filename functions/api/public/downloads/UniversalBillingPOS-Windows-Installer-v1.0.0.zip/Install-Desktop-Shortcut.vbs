Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = oWS.SpecialFolders("Desktop") & "\Universal Billing POS.lnk"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = oWS.CurrentDirectory & "\UniversalBillingPOS-Setup.bat"
oLink.Description = "Universal Billing & POS Desktop Application"
oLink.WorkingDirectory = oWS.CurrentDirectory
oLink.Save
WScript.Echo "Universal Billing POS Desktop shortcut installed on your Windows Desktop!"
