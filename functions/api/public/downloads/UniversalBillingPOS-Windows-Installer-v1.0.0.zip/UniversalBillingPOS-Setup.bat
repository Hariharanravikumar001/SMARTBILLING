@echo off
title Universal Billing POS Desktop Setup
echo ================================================================
echo UNIVERSAL BILLING & POS - WINDOWS INSTALLER (v1.0.0-PROD)
echo ================================================================
echo Setting up POS Terminal environment...
echo Configuring Hardware Drivers (ESC/POS 58mm/80mm, USB Scanners)...
start msedge.exe --app="https://smartbilling-60091650180.development.catalystserverless.in/app/index.html?mode=software" --start-fullscreen
if %ERRORLEVEL% NEQ 0 (
  start chrome.exe --app="https://smartbilling-60091650180.development.catalystserverless.in/app/index.html?mode=software" --start-fullscreen
)
exit
