@echo off
title Universal Billing POS (Portable Counter Edition)
echo Launching Universal Billing POS Portable Terminal...
start msedge.exe --app="https://smartbilling-60091650180.development.catalystserverless.in/app/index.html?mode=software" --window-size=1280,800
exit
