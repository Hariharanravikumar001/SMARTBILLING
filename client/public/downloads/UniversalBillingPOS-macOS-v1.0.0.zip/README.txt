UNIVERSAL BILLING POS - macOS APPLE SILICON & INTEL SUITE
Run Launch-POS-macOS.sh or add to Dock in Safari (File -> Add to Dock).
