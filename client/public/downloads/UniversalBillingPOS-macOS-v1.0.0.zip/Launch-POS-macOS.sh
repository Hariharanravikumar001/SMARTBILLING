#!/bin/bash
echo "Launching Universal Billing POS for macOS..."
open -na "Google Chrome" --args --app="https://smartbilling-60091650180.development.catalystserverless.in/app/index.html?mode=software" || open "https://smartbilling-60091650180.development.catalystserverless.in/app/index.html?mode=software"
