@echo off
title Universal Billing POS Desktop Terminal
echo ======================================================
echo Starting Universal Billing POS Desktop Terminal...
echo Mode: High-Speed In-Store Hardware Terminal
echo ======================================================
start msedge.exe --app="https://smartbilling-60091650180.development.catalystserverless.in/app/index.html?mode=software" --window-size=1280,800
if %ERRORLEVEL% NEQ 0 (
  start chrome.exe --app="https://smartbilling-60091650180.development.catalystserverless.in/app/index.html?mode=software" --window-size=1280,800
)
exit
