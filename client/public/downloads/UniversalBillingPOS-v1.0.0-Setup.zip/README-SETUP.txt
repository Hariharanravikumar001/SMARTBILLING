========================================================================
UNIVERSAL BILLING & POS - DESKTOP SOFTWARE INSTALLATION GUIDE
========================================================================

Version: 1.0.0-PROD
Architecture: Standalone In-Store Terminal Suite

QUICK SETUP INSTRUCTIONS:
1. Extract all files from this ZIP to a folder (e.g. C:\UniversalBillingPOS).
2. Double-click 'Create-Desktop-Shortcut.vbs' to create a 1-click icon on your Windows Desktop.
3. Launch 'UniversalBillingPOS.bat' or use the Desktop shortcut to open the Terminal.
4. On the Terminal Login screen, select your Staff profile or enter your name, then enter your 6-digit security PIN!

DEFAULT DEMO STORE CREDENTIALS:
- Store Owner: Vikramaditya Rao | 6-digit PIN: 123456
- Store Manager: Ananya Sharma  | 6-digit PIN: 654321
- POS Cashier: Sumanth Kumar    | 6-digit PIN: 999999

HARDWARE PERIPHERALS SUPPORTED:
- ESC/POS Thermal Receipt Printers (58mm / 80mm USB / Ethernet)
- USB / Wireless Laser Barcode Handheld Scanners
- Cash Drawer RJ11 Trigger
- Customer Display (VFD)

Need assistance? Contact support@universalbilling.io
========================================================================
