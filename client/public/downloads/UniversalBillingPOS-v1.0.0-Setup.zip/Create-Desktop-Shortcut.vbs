Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = oWS.SpecialFolders("Desktop") & "\Universal Billing POS.lnk"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = oWS.CurrentDirectory & "\UniversalBillingPOS.bat"
oLink.Description = "Universal Billing & POS Desktop Terminal"
oLink.WorkingDirectory = oWS.CurrentDirectory
oLink.Save
WScript.Echo "Universal Billing POS Desktop shortcut created successfully on your Desktop!"
